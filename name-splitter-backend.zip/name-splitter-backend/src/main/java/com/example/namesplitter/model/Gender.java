package com.example.namesplitter.model;

public enum Gender {
    MALE,
    FEMALE,
    DIVERSE
}
