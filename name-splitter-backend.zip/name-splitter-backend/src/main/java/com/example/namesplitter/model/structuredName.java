package com.example.namesplitter.model;

public record structuredName(Gender gender, String title, String firstName, String lastName, String standardizedSalutation){
}
