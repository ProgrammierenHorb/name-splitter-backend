package com.example.namesplitter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NamesplitterApplicationTests {

	@Test
	void contextLoads() {
	}

}
